<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <meta charset="UTF-8">
    <style>
        form {
            height: 350px;
            width: 1000px;
            background-position: center;
            background-color: grey;
            text-align: center;
            padding: 100px;
            margin: 5px;
        }
        header {
            justify-content: center;
            align-items: center;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $fname = $_POST["fname"];
            $lname = $_POST["lname"];
            $username = $_POST["username"];
            $password = $_POST["password"];
            $email = $_POST["email"];
        
            echo "<p><br>Registration successful for user: $username </p>";
            echo "<p><br>Thank you $fname $lname for registering!!!</p>";
        }
        ?>
    </header>
    <form action="" method="POST">
        <h2>Sign Up</h2>
        <label>First name : </label>
        <input type="text" id="fname" name="fname"><br><br>
        <label>Last name : </label>
        <input type="text" id="lname" name="lname"><br><br>

        <label for="username">Username : </label>
        <input type="text" id="username" name="username"><br><br>
        <label for="password">Password : </label>
        <input type="password" id="password" name="password"><br><br>
        <label for="email">Email : </label>
        <input type="email" id="email" name="email"><br><br><br>
        <input type="submit" value="Sign Up">
    </form>
</body>
</html>
