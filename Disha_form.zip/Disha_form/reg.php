
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $tel = $_POST["tel"];
        $mail = $_POST["mail"];
        $pword = $_POST["pword"];
        $gender = $_POST["gender"];
        $selectedState = $_POST["state"];       
		$lang = isset($_POST["lang"]) ? $_POST["lang"] : array(); // Check if lang is set


        echo "<h2>Registration Details</h2>";
        echo "<p><strong>First Name:</strong> $fname</p>";
        echo "<p><strong>Last Name:</strong> $lname</p>";
        echo "<p><strong>Phone Number:</strong> $tel</p>";
        echo "<p><strong>Email:</strong> $mail</p>";
        echo "<p><strong>Gender:</strong> $gender</p>";
		echo "<p><strong>State:</strong> $selectedState</p>";
          if (!empty($lang)) {
            echo "<p><strong>Languages:</strong> " . implode(', ', $lang) . "</p>";
        } else {
            echo "<p><strong>Languages:</strong> None selected</p>";
        }
    }
    ?>
